﻿using ConsultationSite.Data;
using ConsultationSite.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ConsultationSite.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/appointment")]

    public class AppointmentController : Controller
    {
        private readonly ConsultationContext _context;

        public AppointmentController(ConsultationContext context)
        {
            _context = context;
        }

        // GET: api/Appointment
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Appointment>>> GetAppointments()
        {
            return await _context.Appointments
                .Include(a => a.Doctor)
                .Include(a => a.Patient)
                .ToListAsync();
        }

        // GET: api/Appointment/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Appointment>> GetAppointment(int id)
        {
            var appointment = await _context.Appointments
                .Include(a => a.Doctor)
                .Include(a => a.Patient)
                .FirstOrDefaultAsync(a => a.AppointmentID == id);

            if (appointment == null)
                return NotFound();

            return appointment;
        }

        // POST: api/Appointment
        [HttpPost]
        public async Task<ActionResult<Appointment>> PostAppointment(Appointment appointment)
        {
            _context.Appointments.Add(appointment);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetAppointment), new { id = appointment.AppointmentID }, appointment);
        }

        // PUT: api/Appointment/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAppointment(int id, Appointment appointment)
        {
            if (id != appointment.AppointmentID)
                return BadRequest();

            _context.Entry(appointment).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Appointments.Any(a => a.AppointmentID == id))
                    return NotFound();

                throw;
            }

            return NoContent();
        }

        // DELETE: api/Appointment/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAppointment(int id)
        {
            var appointment = await _context.Appointments.FindAsync(id);
            if (appointment == null)
                return NotFound();

            _context.Appointments.Remove(appointment);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        //-----------------------NEW-----------------------
        //[Authorize(Roles = "Patient,Doctor,Admin")]
        //[HttpGet("by-slot")]
        //public async Task<IActionResult> GetAppointmentBySlot(
        //[FromQuery] int patientId,
        //[FromQuery] int doctorId,
        //[FromQuery] DateTime date,
        //[FromQuery] string timeSlot)
        //{
        //    // Normalize and log
        //    date = date.Date;
        //    timeSlot = timeSlot?.Trim();

        //    _logger.LogInformation("Looking for appointment => PatientID: {0}, DoctorID: {1}, Date: {2}, TimeSlot: '{3}'",
        //        patientId, doctorId, date, timeSlot);

        //    var appointment = await _context.Appointments
        //        .Include(a => a.Doctor)
        //        .Include(a => a.Patient)
        //        .FirstOrDefaultAsync(a =>
        //            a.PatientID == patientId &&
        //            a.DoctorID == doctorId &&
        //            a.Date.Date == date &&
        //            a.TimeSlot.Trim() == timeSlot);

        //    if (appointment == null)
        //        return NotFound("No appointment found for the specified slot.");

        //    return Ok(appointment);
        //}

        //get appointment by docterid
        [Authorize(Roles = "Patient,Doctor,Admin")]
        [HttpGet("doctor/{doctorId}")]
        public async Task<IActionResult> GetAppointmentsForDoctor(int doctorId)
        {
            var appointments = await _context.Appointments
                .Where(a => a.DoctorID == doctorId)
                .Include(a => a.Patient)
                .OrderBy(a => a.Date)
                .ToListAsync();

            if (appointments == null || !appointments.Any())
            {
                return NotFound($"No appointments found for DoctorID {doctorId}");
            }

            return Ok(appointments);
        }



    }
}

