﻿using ConsultationSite.Data;
using ConsultationSite.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;

namespace ConsultationSite.Controllers
{
    [ApiController]
    [Route("api/login")]
    public class LoginController : Controller
    {
        private readonly ConsultationContext _context;
        private readonly TokenService _tokenService;

        public LoginController(ConsultationContext context, TokenService tokenService)
        {
            _context = context;
            _tokenService = tokenService;
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Login([FromBody] Login model)
        {
            if (string.IsNullOrWhiteSpace(model.Role))
                return BadRequest("Role is required");

            object userResponse = null;

            switch (model.Role.ToLower())
            {
                case "admin":
                    var admin = await _context.Admins
                        .FirstOrDefaultAsync(a => a.Email == model.Email && a.Password == model.Password);
                    if (admin == null) return Unauthorized("Invalid credentials");
                    userResponse = new
                    {
                        admin.AdminID,
                        admin.Username,
                        admin.Email,
                        Role = "Admin"
                    };
                    break;

                case "doctor":
                    var doctor = await _context.Doctors
                        .FirstOrDefaultAsync(d => d.Email == model.Email && d.Password == model.Password);
                    if (doctor == null) return Unauthorized("Invalid credentials");
                    userResponse = new
                    {
                        doctor.DoctorID,
                        doctor.Name,
                        doctor.Email,
                        doctor.Specialization,
                        doctor.Experience,
                        doctor.ContactNumber,
                        doctor.ProfileStatus,
                        doctor.Doctor_Image,
                        Role = "Doctor"
                    };
                    break;

                case "patient":
                    var patient = await _context.Patients
                        .FirstOrDefaultAsync(p => p.Email == model.Email && p.Password == model.Password);
                    if (patient == null) return Unauthorized("Invalid credentials");
                    userResponse = new
                    {
                        patient.PatientID,
                        patient.Name,
                        patient.Email,
                        patient.Gender,
                        patient.ContactNumber,
                        Role = "Patient"
                    };
                    break;

                default:
                    return BadRequest("Invalid role");
            }

            var token = _tokenService.CreateToken(model.Email, model.Role);

            return Ok(new
            {
                token = token,
                user = userResponse
            });
        }
    }
}
